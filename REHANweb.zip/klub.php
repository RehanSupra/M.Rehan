<?php
include 'config.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Tambah klub
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $negara = $_POST['negara'];
    mysqli_query($koneksi, "INSERT INTO klub (nama_klub, negara) VALUES ('$nama', '$negara')");
    header("Location: klub.php");
}

// Hapus klub
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM klub WHERE id_klub = '$id'");
    header("Location: klub.php");
}

// Edit klub
if (isset($_POST['edit'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $negara = $_POST['negara'];
    mysqli_query($koneksi, "UPDATE klub SET nama_klub='$nama', negara='$negara' WHERE id_klub='$id'");
    header("Location: klub.php");
}

$data = mysqli_query($koneksi, "SELECT * FROM klub ORDER BY nama_klub ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Klub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#"><i class="bi bi-person-circle me-2"></i>BOLA.NET ⚽</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <<li class="nav-item"><a class="nav-link" href="index.php">🏡 Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="pemain.php">👟 Data Pemain</a></li>
                <li class="nav-item"><a class="nav-link" href="klub.php">🛡 Data Klub</a></li>
                <li class="nav-item"><a class="nav-link" href="statistik.php">📊 Statistik</a></li>
                <li class="nav-item"><a class="nav-link" href="cari.php">🔍 Pencarian</a></li>
                <li class="nav-item"><a class="nav-link" href="berita.php">📰Berita Bola</a></li>
                <li class="nav-item"><a class="nav-link" href="jadwal.php">📅Jadwal Pertandingan</a></li>
                <li class="nav-item"><a class="nav-link" href="galeri.php">🖼️Galeri Pemain</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="btn btn-outline-light" href="logout.php"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten -->
<div class="container">
    <h3 class="mb-4 text-dark">🏟️ Data Klub Sepak Bola</h3>

    <!-- Form Tambah Klub -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white"><strong><i class="bi bi-plus-circle me-1"></i>Tambah Klub</strong></div>
        <div class="card-body">
            <form method="post">
                <div class="row g-2">
                    <div class="col-md-6">
                        <input type="text" name="nama" class="form-control" placeholder="Nama Klub" required>
                    </div>
                    <div class="col-md-4">
                        <input type="text" name="negara" class="form-control" placeholder="Negara Asal" required>
                    </div>
                    <div class="col-md-2 d-grid">
                        <button type="submit" name="tambah" class="btn btn-success"><i class="bi bi-save"></i> Simpan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel Data Klub -->
    <div class="table-responsive shadow-sm">
        <table class="table table-bordered table-striped table-hover align-middle">
            <thead class="table-dark text-center">
                <tr>
                    <th>No</th>
                    <th>Nama Klub</th>
                    <th>Negara</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($d = mysqli_fetch_array($data)) { ?>
                <tr>
                    <td class="text-center"><?= $no++ ?></td>
                    <td><?= $d['nama_klub'] ?></td>
                    <td><?= $d['negara'] ?></td>
                    <td class="text-center">
                        <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#edit<?= $d['id_klub'] ?>">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <a href="?hapus=<?= $d['id_klub'] ?>" onclick="return confirm('Hapus klub ini?')" class="btn btn-sm btn-danger">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>

                <!-- Modal Edit Klub -->
                <div class="modal fade" id="edit<?= $d['id_klub'] ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <form method="post" class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Edit Klub</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="id" value="<?= $d['id_klub'] ?>">
                                <input type="text" name="nama" class="form-control mb-2" value="<?= $d['nama_klub'] ?>" required>
                                <input type="text" name="negara" class="form-control" value="<?= $d['negara'] ?>" required>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" name="edit" class="btn btn-primary">Simpan</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            </div>
                        </form>
                    </div>
                </div>

                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
