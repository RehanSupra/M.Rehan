<?php
// berita.php
include 'config.php';
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

if (isset($_POST['tambah'])) {
    $judul = $_POST['judul'];
    $isi = $_POST['isi'];
    $tanggal = date('Y-m-d');
    mysqli_query($koneksi, "INSERT INTO berita (judul, isi, tanggal) VALUES ('$judul', '$isi', '$tanggal')");
    header("Location: berita.php");
}
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM berita WHERE id_berita = '$id'");
    header("Location: berita.php");
}
$data = mysqli_query($koneksi, "SELECT * FROM berita ORDER BY tanggal DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Berita Bola</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#"><i class="bi bi-search me-2"></i>Berita Bola ⚽</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">🏡 Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="pemain.php">👟 Data Pemain</a></li>
                <li class="nav-item"><a class="nav-link" href="klub.php">🛡 Data Klub</a></li>
                <li class="nav-item"><a class="nav-link" href="statistik.php">📊 Statistik</a></li>
                <li class="nav-item"><a class="nav-link" href="cari.php">🔍 Pencarian</a></li>
                <li class="nav-item"><a class="nav-link" href="berita.php">📰Berita Bola</a></li>
                <li class="nav-item"><a class="nav-link" href="jadwal.php">📅Jadwal Pertandingan</a></li>
                <li class="nav-item"><a class="nav-link" href="galeri.php">🖼️Galeri Pemain</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="logout.php" class="btn btn-outline-light"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container py-5">
    <h3 class="text-primary mb-4">📰 Berita Bola</h3>
    <form method="post" class="mb-3 row g-2 align-items-center">
        <div class="col-md-4">
            <input type="text" name="judul" class="form-control" placeholder="Judul" required>
        </div>
        <div class="col-md-4">
            <textarea name="isi" class="form-control" placeholder="Isi Berita" required></textarea>
        </div>
        <div class="col-md-2">
            <button type="submit" name="tambah" class="btn btn-success w-100">Tambah</button>
        </div>
    </form>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr><th>Judul</th><th>Tanggal</th><th>Aksi</th></tr>
        </thead>
        <tbody>
        <?php while ($d = mysqli_fetch_array($data)) { ?>
            <tr>
                <td><?= $d['judul'] ?></td>
                <td><?= $d['tanggal'] ?></td>
                <td><a href="?hapus=<?= $d['id_berita'] ?>" class="btn btn-danger btn-sm">Hapus</a></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
