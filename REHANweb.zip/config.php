<?php
// config.php

// Mulai session agar bisa digunakan untuk login
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


// Sertakan file koneksi
include 'koneksi.php';
?>
