<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'config.php';

$cari = '';
if (isset($_GET['cari'])) {
    $cari = $_GET['cari'];
}

$query = "SELECT pemain.*, klub.nama_klub, agen.nama_agen
          FROM pemain
          LEFT JOIN klub ON pemain.id_klub = klub.id_klub
          LEFT JOIN agen ON pemain.id_agen = agen.id_agen
          WHERE pemain.nama_pemain LIKE '%$cari%' 
          OR pemain.posisi LIKE '%$cari%'
          OR klub.nama_klub LIKE '%$cari%'";

$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cari Pemain</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#"><i class="bi bi-search me-2"></i>Pencarian Pemain</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">🏡 Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="pemain.php">👟 Data Pemain</a></li>
                <li class="nav-item"><a class="nav-link" href="klub.php">🛡 Data Klub</a></li>
                <li class="nav-item"><a class="nav-link" href="statistik.php">📊 Statistik</a></li>
                <li class="nav-item"><a class="nav-link" href="cari.php">🔍 Pencarian</a></li>
                <li class="nav-item"><a class="nav-link" href="berita.php">📰Berita Bola</a></li>
                <li class="nav-item"><a class="nav-link" href="jadwal.php">📅Jadwal Pertandingan</a></li>
                <li class="nav-item"><a class="nav-link" href="galeri.php">🖼️Galeri Pemain</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="logout.php" class="btn btn-outline-light"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten -->
<div class="container">
    <h3 class="text-dark mb-4">🔎 Cari Data Pemain Sepak Bola</h3>

    <!-- Form Pencarian -->
    <form method="GET" action="cari.php" class="row g-2 mb-4">
        <div class="col-md-10">
            <input type="text" name="cari" class="form-control" placeholder="Ketik nama, posisi, atau klub..." value="<?= htmlspecialchars($cari) ?>" autofocus>
        </div>
        <div class="col-md-2 d-grid">
            <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i> Cari</button>
        </div>
    </form>

    <!-- Hasil Pencarian -->
    <div class="table-responsive shadow-sm">
        <table class="table table-bordered table-striped table-hover align-middle">
            <thead class="table-dark text-center">
                <tr>
                    <th>No</th>
                    <th>Nama Pemain</th>
                    <th>Posisi</th>
                    <th>Umur</th>
                    <th>Klub</th>
                    <th>Agen</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td class='text-center'>" . $no++ . "</td>";
                        echo "<td>" . htmlspecialchars($row['nama_pemain']) . "</td>";
                        echo "<td class='text-center'>" . htmlspecialchars($row['posisi']) . "</td>";
                        echo "<td class='text-center'>" . htmlspecialchars($row['umur']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['nama_klub']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['nama_agen']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center text-muted'>Tidak ada data ditemukan.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<!-- JS Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
