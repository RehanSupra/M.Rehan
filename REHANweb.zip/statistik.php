<?php
session_start();
include 'config.php';

// Cek login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Tambah data
if (isset($_POST['tambah'])) {
    $id_pemain = $_POST['id_pemain'];
    $gol = $_POST['gol'];
    $assist = $_POST['assist'];
    $kuning = $_POST['kartu_kuning'];
    $merah = $_POST['kartu_merah'];

    mysqli_query($koneksi, "INSERT INTO statistik (id_pemain, gol, assist, kartu_kuning, kartu_merah)
                            VALUES ('$id_pemain', '$gol', '$assist', '$kuning', '$merah')");
    header("Location: statistik.php");
    exit;
}

// Hapus data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM statistik WHERE id_statistik = '$id'");
    header("Location: statistik.php");
    exit;
}

// Edit data
if (isset($_POST['edit'])) {
    $id = $_POST['id'];
    $gol = $_POST['gol'];
    $assist = $_POST['assist'];
    $kuning = $_POST['kartu_kuning'];
    $merah = $_POST['kartu_merah'];

    mysqli_query($koneksi, "UPDATE statistik SET 
        gol = '$gol', 
        assist = '$assist', 
        kartu_kuning = '$kuning', 
        kartu_merah = '$merah' 
        WHERE id_statistik = '$id'");
    header("Location: statistik.php");
    exit;
}

// Ambil data gabungan pemain dan statistik
$data = mysqli_query($koneksi, 
    "SELECT s.*, p.nama_pemain FROM statistik s 
     JOIN pemain p ON s.id_pemain = p.id_pemain");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Statistik Pemain</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#"><i class="bi bi-person-circle me-2"></i>BOLA.NET ⚽</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">🏡 Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="pemain.php">👟 Data Pemain</a></li>
                <li class="nav-item"><a class="nav-link" href="klub.php">🛡 Data Klub</a></li>
                <li class="nav-item"><a class="nav-link" href="statistik.php">📊 Statistik</a></li>
                <li class="nav-item"><a class="nav-link" href="cari.php">🔍 Pencarian</a></li>
                <li class="nav-item"><a class="nav-link" href="berita.php">📰Berita Bola</a></li>
                <li class="nav-item"><a class="nav-link" href="jadwal.php">📅Jadwal Pertandingan</a></li>
                <li class="nav-item"><a class="nav-link" href="galeri.php">🖼️Galeri Pemain</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="btn btn-outline-light" href="logout.php"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten -->
<div class="container">
    <h3 class="text-dark mb-4">📊 Statistik Pemain Sepak Bola</h3>

    <!-- Form Tambah Statistik -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-success text-white fw-semibold">
            <i class="bi bi-plus-circle me-1"></i>Tambah Statistik
        </div>
        <div class="card-body">
            <form method="post">
                <div class="row g-2">
                    <div class="col-md-3">
                        <select name="id_pemain" class="form-select" required>
                            <option value="">-- Pilih Pemain --</option>
                            <?php
                            $pemain = mysqli_query($koneksi, "SELECT * FROM pemain");
                            while ($p = mysqli_fetch_array($pemain)) {
                                echo "<option value='{$p['id_pemain']}'>{$p['nama_pemain']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col"><input type="number" name="gol" class="form-control" placeholder="Gol" required></div>
                    <div class="col"><input type="number" name="assist" class="form-control" placeholder="Assist" required></div>
                    <div class="col"><input type="number" name="kartu_kuning" class="form-control" placeholder="Kartu Kuning" required></div>
                    <div class="col"><input type="number" name="kartu_merah" class="form-control" placeholder="Kartu Merah" required></div>
                    <div class="col-md-1 d-grid">
                        <button type="submit" name="tambah" class="btn btn-success"><i class="bi bi-save"></i></button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel Statistik -->
    <div class="table-responsive shadow-sm">
        <table class="table table-bordered table-striped table-hover align-middle">
            <thead class="table-dark text-center">
                <tr>
                    <th>No</th>
                    <th>Nama Pemain</th>
                    <th>Gol</th>
                    <th>Assist</th>
                    <th>Kartu Kuning</th>
                    <th>Kartu Merah</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($d = mysqli_fetch_array($data)) { ?>
                <tr>
                    <td class="text-center"><?= $no++ ?></td>
                    <td><?= $d['nama_pemain'] ?></td>
                    <td class="text-center"><?= $d['gol'] ?></td>
                    <td class="text-center"><?= $d['assist'] ?></td>
                    <td class="text-center"><?= $d['kartu_kuning'] ?></td>
                    <td class="text-center"><?= $d['kartu_merah'] ?></td>
                    <td class="text-center">
                        <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#edit<?= $d['id_statistik'] ?>">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <a href="?hapus=<?= $d['id_statistik'] ?>" onclick="return confirm('Yakin ingin menghapus?')" class="btn btn-sm btn-danger">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>

                <!-- Modal Edit -->
                <div class="modal fade" id="edit<?= $d['id_statistik'] ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <form method="post" class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Edit Statistik</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="id" value="<?= $d['id_statistik'] ?>">
                                <input type="number" name="gol" class="form-control mb-2" value="<?= $d['gol'] ?>" required>
                                <input type="number" name="assist" class="form-control mb-2" value="<?= $d['assist'] ?>" required>
                                <input type="number" name="kartu_kuning" class="form-control mb-2" value="<?= $d['kartu_kuning'] ?>" required>
                                <input type="number" name="kartu_merah" class="form-control" value="<?= $d['kartu_merah'] ?>" required>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" name="edit" class="btn btn-primary">Simpan</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            </div>
                        </form>
                    </div>
                </div>

                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
