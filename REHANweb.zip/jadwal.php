<?php
// jadwal.php
include 'config.php';
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Proses tambah jadwal
if (isset($_POST['tambah'])) {
    $tanggal = $_POST['tanggal'];
    $tim_a = $_POST['tim_a'];
    $tim_b = $_POST['tim_b'];
    $lokasi = $_POST['lokasi'];
    mysqli_query($koneksi, "INSERT INTO jadwal (tanggal, tim_a, tim_b, lokasi) VALUES ('$tanggal', '$tim_a', '$tim_b', '$lokasi')");
    header("Location: jadwal.php");
}

// Proses hapus jadwal
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM jadwal WHERE id_jadwal = '$id'");
    header("Location: jadwal.php");
}

// Ambil data
$data = mysqli_query($koneksi, "SELECT * FROM jadwal ORDER BY tanggal DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Jadwal Pertandingan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#"><i class="bi bi-calendar-event me-2"></i>Jadwal Bola</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="index.php">🏠 Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="pemain.php">👟 Data Pemain</a></li>
                <li class="nav-item"><a class="nav-link" href="klub.php">🛡 Klub</a></li>
                <li class="nav-item"><a class="nav-link" href="statistik.php">📊 Statistik</a></li>
                <li class="nav-item"><a class="nav-link" href="cari.php">🔍 Pencarian</a></li>
                <li class="nav-item"><a class="nav-link" href="berita.php">📰 Berita</a></li>
                <li class="nav-item"><a class="nav-link active" href="jadwal.php">📅 Jadwal</a></li>
                <li class="nav-item"><a class="nav-link" href="galeri.php">🖼️ Galeri</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="logout.php" class="btn btn-outline-light"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten -->
<div class="container">
    <h3 class="text-success mb-4">📅 Jadwal Pertandingan</h3>

    <!-- Form Tambah Jadwal -->
    <form method="post" class="row g-2 mb-4">
        <div class="col-md-2">
            <input type="date" name="tanggal" class="form-control" required>
        </div>
        <div class="col-md-2">
            <input type="text" name="tim_a" class="form-control" placeholder="Tim A" required>
        </div>
        <div class="col-md-2">
            <input type="text" name="tim_b" class="form-control" placeholder="Tim B" required>
        </div>
        <div class="col-md-4">
            <input type="text" name="lokasi" class="form-control" placeholder="Lokasi Pertandingan" required>
        </div>
        <div class="col-md-2">
            <button type="submit" name="tambah" class="btn btn-success w-100">Tambah</button>
        </div>
    </form>

    <!-- Tabel Jadwal -->
    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-dark text-center">
                <tr>
                    <th>Tanggal</th>
                    <th>Pertandingan</th>
                    <th>Lokasi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($d = mysqli_fetch_array($data)) { ?>
                <tr>
                    <td class="text-center"><?= $d['tanggal'] ?></td>
                    <td><?= $d['tim_a'] ?> <strong>vs</strong> <?= $d['tim_b'] ?></td>
                    <td><?= $d['lokasi'] ?></td>
                    <td class="text-center">
                        <a href="?hapus=<?= $d['id_jadwal'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus jadwal ini?')">
                            <i class="bi bi-trash"></i> Hapus
                        </a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
