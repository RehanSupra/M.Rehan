<?php
// pemain.php

include 'config.php';

// Cek login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Tambah Pemain
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $posisi = $_POST['posisi'];
    $umur = $_POST['umur'];
    $klub = $_POST['klub'];
    $agen_id = $_POST['agen'];

    mysqli_query($koneksi, "INSERT INTO pemain (nama_pemain, posisi, umur, id_klub, id_agen) 
                            VALUES ('$nama', '$posisi', '$umur', '$klub', '$agen_id')");
    header("Location: pemain.php");
}

// Hapus Pemain
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM pemain WHERE id_pemain = '$id'");
    header("Location: pemain.php");
}

// Edit Pemain
if (isset($_POST['edit'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $posisi = $_POST['posisi'];
    $umur = $_POST['umur'];
    $klub = $_POST['klub'];
    $agen_id = $_POST['agen'];

    mysqli_query($koneksi, "UPDATE pemain SET 
        nama_pemain='$nama', posisi='$posisi', umur='$umur', id_klub='$klub', id_agen='$agen_id' 
        WHERE id_pemain='$id'");
    header("Location: pemain.php");
}

// Pencarian
$keyword = "";
if (isset($_GET['cari'])) {
    $keyword = $_GET['cari'];
    $data = mysqli_query($koneksi, 
        "SELECT p.*, k.nama_klub, a.nama_agen FROM pemain p
         JOIN klub k ON p.id_klub = k.id_klub
         JOIN agen a ON p.id_agen = a.id_agen
         WHERE p.nama_pemain LIKE '%$keyword%'");
} else {
    $data = mysqli_query($koneksi, 
        "SELECT p.*, k.nama_klub, a.nama_agen FROM pemain p
         JOIN klub k ON p.id_klub = k.id_klub
         JOIN agen a ON p.id_agen = a.id_agen");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Pemain</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#"><i class="bi bi-person-circle me-2"></i>BOLA.NET ⚽</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">🏡 Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="pemain.php">👟 Data Pemain</a></li>
                <li class="nav-item"><a class="nav-link" href="klub.php">🛡 Data Klub</a></li>
                <li class="nav-item"><a class="nav-link" href="statistik.php">📊 Statistik</a></li>
                <li class="nav-item"><a class="nav-link" href="cari.php">🔍 Pencarian</a></li>
                <li class="nav-item"><a class="nav-link" href="berita.php">📰Berita Bola</a></li>
                <li class="nav-item"><a class="nav-link" href="jadwal.php">📅Jadwal Pertandingan</a></li>
                <li class="nav-item"><a class="nav-link" href="galeri.php">🖼️Galeri Pemain</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="btn btn-outline-light" href="logout.php"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- MAIN CONTAINER -->
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="text-dark">📋 Data Pemain Sepak Bola</h3>
    </div>

    <!-- FORM CARI -->
    <form class="input-group mb-4" method="get">
        <input type="search" class="form-control" name="cari" placeholder="Cari pemain..." value="<?= $keyword ?>">
        <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i> Cari</button>
    </form>

    <!-- FORM TAMBAH -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white">
            <strong><i class="bi bi-plus-circle me-1"></i>Tambah Pemain</strong>
        </div>
        <div class="card-body">
            <form method="post">
                <div class="row mb-3">
                    <div class="col-md-4"><input type="text" name="nama" class="form-control" placeholder="Nama Pemain" required></div>
                    <div class="col-md-4"><input type="text" name="posisi" class="form-control" placeholder="Posisi" required></div>
                    <div class="col-md-4"><input type="number" name="umur" class="form-control" placeholder="Umur" required></div>
                </div>
                <div class="row">
                    <div class="col-md-5">
                        <select name="klub" class="form-select" required>
                            <option value="">-- Pilih Klub --</option>
                            <?php
                            $list_klub = mysqli_query($koneksi, "SELECT * FROM klub");
                            while ($k = mysqli_fetch_array($list_klub)) {
                                echo "<option value='$k[id_klub]'>$k[nama_klub]</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <select name="agen" class="form-select" required>
                            <option value="">-- Pilih Agen --</option>
                            <?php
                            $list_agen = mysqli_query($koneksi, "SELECT * FROM agen");
                            while ($a = mysqli_fetch_array($list_agen)) {
                                echo "<option value='$a[id_agen]'>$a[nama_agen]</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-2 d-grid">
                        <button type="submit" name="tambah" class="btn btn-success"><i class="bi bi-save"></i> Simpan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- TABEL DATA -->
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover align-middle shadow-sm">
            <thead class="table-dark">
                <tr class="text-center">
                    <th>No</th>
                    <th>Nama</th>
                    <th>Posisi</th>
                    <th>Umur</th>
                    <th>Klub</th>
                    <th>Agen</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($d = mysqli_fetch_array($data)) { ?>
                <tr>
                    <td class="text-center"><?= $no++ ?></td>
                    <td><?= $d['nama_pemain'] ?></td>
                    <td><?= $d['posisi'] ?></td>
                    <td class="text-center"><?= $d['umur'] ?></td>
                    <td><?= $d['nama_klub'] ?></td>
                    <td><?= $d['nama_agen'] ?></td>
                    <td class="text-center">
                        <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#edit<?= $d['id_pemain'] ?>">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <a href="?hapus=<?= $d['id_pemain'] ?>" onclick="return confirm('Hapus data ini?')" class="btn btn-sm btn-danger">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>

                <!-- MODAL EDIT -->
                <div class="modal fade" id="edit<?= $d['id_pemain'] ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <form method="post" class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Edit Pemain</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="id" value="<?= $d['id_pemain'] ?>">
                                <input type="text" name="nama" class="form-control mb-2" value="<?= $d['nama_pemain'] ?>" required>
                                <input type="text" name="posisi" class="form-control mb-2" value="<?= $d['posisi'] ?>" required>
                                <input type="number" name="umur" class="form-control mb-2" value="<?= $d['umur'] ?>" required>
                                
                                <select name="klub" class="form-select mb-2" required>
                                    <option value="">-- Pilih Klub --</option>
                                    <?php
                                    $list_klub = mysqli_query($koneksi, "SELECT * FROM klub");
                                    while ($k = mysqli_fetch_array($list_klub)) {
                                        $sel = ($k['id_klub'] == $d['id_klub']) ? "selected" : "";
                                        echo "<option value='$k[id_klub]' $sel>$k[nama_klub]</option>";
                                    }
                                    ?>
                                </select>

                                <select name="agen" class="form-select" required>
                                    <option value="">-- Pilih Agen --</option>
                                    <?php
                                    $list_agen = mysqli_query($koneksi, "SELECT * FROM agen");
                                    while ($a = mysqli_fetch_array($list_agen)) {
                                        $sel = ($a['id_agen'] == $d['id_agen']) ? "selected" : "";
                                        echo "<option value='$a[id_agen]' $sel>$a[nama_agen]</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" name="edit" class="btn btn-primary">Simpan</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            </div>
                        </form>
                    </div>
                </div>

                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
