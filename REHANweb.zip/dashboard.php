<?php
// dashboard.php

session_start();
include 'config.php';

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f0f4f7, #d9e4f5);
            font-family: 'Segoe UI', sans-serif;
        }
        .card-hover {
            transition: all 0.3s ease-in-out;
            border-radius: 16px;
        }
        .card-hover:hover {
            transform: translateY(-7px);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.15);
        }
        .icon-circle {
            width: 70px;
            height: 70px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            font-size: 1.8rem;
            margin: 0 auto 15px;
        }
        footer {
            background: #212529;
            color: #fff;
            padding: 20px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        .navbar-brand i {
            margin-right: 8px;
        }
        h2 {
            font-weight: 700;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="bi bi-person-circle"></i>BOLA.NET ⚽</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                
                <li class="nav-item"><a class="nav-link" href="index.php">🏡 Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="pemain.php">👟 Data Pemain</a></li>
                <li class="nav-item"><a class="nav-link" href="klub.php">🛡 Data Klub</a></li>
                <li class="nav-item"><a class="nav-link" href="statistik.php">📊 Statistik</a></li>
                <li class="nav-item"><a class="nav-link" href="cari.php">🔍 Pencarian</a></li>
                <li class="nav-item"><a class="nav-link" href="berita.php">📰Berita Bola</a></li>
                <li class="nav-item"><a class="nav-link" href="jadwal.php">📅Jadwal Pertandingan</a></li>
                <li class="nav-item"><a class="nav-link" href="galeri.php">🖼️Galeri Pemain</a></li>

            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="btn btn-danger" href="logout.php">🚪 Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten Utama -->
<div class="container mt-5 mb-5">
    <div class="text-center mb-5">
        <h2>👋 Selamat Datang, <span class="text-primary"><?php echo $_SESSION['username']; ?></span>!</h2>
        <p class="text-muted">Kelola data pemain sepak bola dengan cepat dan mudah melalui panel ini.</p>
    </div>

    <!-- Kartu Navigasi -->
    <div class="row g-4">
        <div class="col-md-3">
            <div class="card text-center shadow-sm card-hover">
                <div class="card-body">
                    <div class="icon-circle bg-primary text-white">
                        <i class="bi bi-people-fill"></i>
                    </div>
                    <h5 class="card-title mt-2">Data Pemain</h5>
                    <a href="pemain.php" class="btn btn-outline-primary btn-sm mt-2">👟 Lihat</a>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-center shadow-sm card-hover">
                <div class="card-body">
                    <div class="icon-circle bg-success text-white">
                        <i class="bi bi-shield-fill"></i>
                    </div>
                    <h5 class="card-title mt-2">Data Klub</h5>
                    <a href="klub.php" class="btn btn-outline-success btn-sm mt-2">🛡 Lihat</a>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-center shadow-sm card-hover">
                <div class="card-body">
                    <div class="icon-circle bg-warning text-white">
                        <i class="bi bi-bar-chart-fill"></i>
                    </div>
                    <h5 class="card-title mt-2">Statistik Pemain</h5>
                    <a href="statistik.php" class="btn btn-outline-warning btn-sm mt-2">📊 Lihat</a>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-center shadow-sm card-hover">
                <div class="card-body">
                    <div class="icon-circle bg-info text-white">
                        <i class="bi bi-search"></i>
                    </div>
                    <h5 class="card-title mt-2">Pencarian</h5>
                    <a href="cari.php" class="btn btn-outline-info btn-sm mt-2">🔍 Cari</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="text-center">
    <div class="container">
        <p class="mb-0">© <?= date('Y'); ?> Website Portofolio Pemain Sepak Bola ⚽ | Praktikum Web</p>
    </div>
</footer>

<!-- JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
