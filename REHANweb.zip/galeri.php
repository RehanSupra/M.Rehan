<?php
// galeri.php
include 'config.php';
if (session_status() === PHP_SESSION_NONE) session_start();
if (isset($_POST['tambah'])) {
    $id_pemain = $_POST['id_pemain'];
    $keterangan = $_POST['keterangan'];

    // Validasi file foto
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === 0) {
        $foto = $_FILES['foto']['name'];
        $tmp = $_FILES['foto']['tmp_name'];

        // Hindari nama file bentrok
        $ext = pathinfo($foto, PATHINFO_EXTENSION);
        $namaBaru = uniqid('img_') . '.' . $ext;

        // Buat folder uploads kalau belum ada
        if (!is_dir('uploads')) mkdir('uploads', 0777, true);

        // Upload file
        if (move_uploaded_file($tmp, 'uploads/' . $namaBaru)) {
            mysqli_query($koneksi, "INSERT INTO galeri (id_pemain, foto, keterangan) VALUES ('$id_pemain', '$namaBaru', '$keterangan')");
        } else {
            echo "<script>alert('Gagal mengupload gambar');</script>";
        }
    } else {
        echo "<script>alert('Pilih gambar terlebih dahulu');</script>";
    }

    header("Location: galeri.php");
    exit;
}

// Ambil data
$data = mysqli_query($koneksi, "SELECT g.*, p.nama_pemain FROM galeri g JOIN pemain p ON g.id_pemain=p.id_pemain");
$pemain = mysqli_query($koneksi, "SELECT * FROM pemain");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Galeri Pemain</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#"><i class="bi bi-images me-2"></i>Galeri Bola</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="index.php">🏠 Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="pemain.php">👟 Pemain</a></li>
                <li class="nav-item"><a class="nav-link" href="klub.php">🛡 Klub</a></li>
                <li class="nav-item"><a class="nav-link" href="statistik.php">📊 Statistik</a></li>
                <li class="nav-item"><a class="nav-link" href="cari.php">🔍 Pencarian</a></li>
                <li class="nav-item"><a class="nav-link" href="berita.php">📰 Berita</a></li>
                <li class="nav-item"><a class="nav-link" href="jadwal.php">📅 Jadwal</a></li>
                <li class="nav-item"><a class="nav-link active" href="galeri.php">🖼️ Galeri</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="logout.php" class="btn btn-outline-light"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten -->
<div class="container">
    <h3 class="text-info mb-4">🖼️ Galeri Pemain</h3>

    <!-- Form Upload -->
     <form method="post" enctype="multipart/form-data">
        <div class="col-md-3">
            <select name="id_pemain" class="form-select" required>
                <option value="">-- Pilih Pemain --</option>
                <?php while ($p = mysqli_fetch_array($pemain)) {
                    echo "<option value='$p[id_pemain]'>$p[nama_pemain]</option>";
                } ?>
            </select>
        </div>
        <div class="col-md-3">
            <input type="file" name="foto" class="form-control" required>
        </div>
        <div class="col-md-4">
            <input type="text" name="keterangan" class="form-control" placeholder="Keterangan (opsional)">
        </div>
        <div class="col-md-2">
            <button type="submit" name="tambah" class="btn btn-info w-100">Tambah</button>
        </div>
    </form>

    <!-- Tabel Galeri -->
    <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle">
            <thead class="table-dark text-center">
                <tr>
                    <th>Pemain</th>
                    <th>Foto</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($d = mysqli_fetch_array($data)) { ?>
                <tr>
                    <td class="text-center"><?= $d['nama_pemain'] ?></td>
                    <td class="text-center">
                       <img src="uploads/<?= $d['foto'] ?>" width="100" class="img-thumbnail">
                    </td>
                    <td><?= $d['keterangan'] ?: '-' ?></td>
                    <td class="text-center">
                        <a href="hapus_galeri.php?id=<?= $d['id_galeri'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus foto ini?')">
    <i class="bi bi-trash"></i> Hapus
</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
