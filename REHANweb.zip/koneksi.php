<?php
// koneksi.php

// Membuat koneksi ke database MySQL
$koneksi = mysqli_connect("localhost", "root", "", "db_pemain");

// Mengecek apakah koneksi berhasil
if (!$koneksi) {
    // Jika koneksi gagal, tampilkan pesan error
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
