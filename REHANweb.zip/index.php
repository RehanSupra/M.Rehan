<?php
// index.php

// Mulai session
session_start();

// Jika sudah login, redirect langsung ke dashboard
if (isset($_SESSION['username'])) {
    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Home | Website Pemain Sepak Bola</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        footer {
            background-color: #212529;
            color: white;
            padding: 15px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body class="bg-light">

    <!-- Navbar Publik -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <!-- Logo / Judul -->
            <a class="navbar-brand" href="#"><i class="bi bi-dribbble"></i> Pemain Bola</a>

            <!-- Tombol hamburger -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Menu -->
            <div class="collapse navbar-collapse" id="navbarContent">
                <ul class="navbar-nav me-auto">
                    <!-- Menu publik -->
                    <li class="nav-item"><a class="nav-link active" href="index.php"><i class="bi bi-house"></i> Beranda</a></li>
                    <li class="nav-item"><a class="nav-link" href="cari.php"><i class="bi bi-search"></i> Cari Pemain</a></li>
                </ul>
                <!-- Tombol Login -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="login.php" class="btn btn-outline-light"><i class="bi bi-box-arrow-in-right"></i> Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Konten Utama -->
    <div class="container mt-5 text-center">
        <h1 class="display-5">Website Portofolio Pemain Sepak Bola</h1>
        <p class="lead text-muted">Temukan data, klub, dan statistik lengkap pemain bola Indonesia dan dunia.</p>
        <div class="mt-4">
            <a href="cari.php" class="btn btn-success btn-lg">
                <i class="bi bi-search"></i> Cari Pemain Sekarang
            </a>
        </div>
    </div>

    <!-- Footer -->
    <footer class="text-center mt-5">
        <div class="container">
            <small>© <?php echo date('Y'); ?> Website Pemain Bola. Dibuat untuk keperluan praktikum.</small>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
