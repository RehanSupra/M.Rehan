<?php
// login.php

session_start();
include 'config.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    $query = mysqli_query($koneksi, "SELECT * FROM user WHERE username='$username' AND password='$password'");
    $cek = mysqli_num_rows($query);

    if ($cek > 0) {
        $_SESSION['username'] = $username;
        header("Location: dashboard.php");
    } else {
        echo "<script>alert('Login gagal! Username atau password salah.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>🔐 Login Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #74ebd5, #9face6);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card {
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }
        .form-control {
            border-radius: 10px;
        }
        .btn-primary {
            border-radius: 10px;
        }
        .input-group-text {
            border-radius: 10px 0 0 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card">
                    <div class="card-header text-white bg-primary text-center rounded-top">
                        <h3 class="my-2">🔐 Login Admin</h3>
                    </div>
                    <div class="card-body">
                        <form method="post">
                            <!-- Username -->
                            <div class="mb-3">
                                <label class="form-label">👤 Username</label>
                                <div class="input-group">
                                    <span class="input-group-text">👤</span>
                                    <input type="text" name="username" class="form-control" placeholder="Masukkan username" required>
                                </div>
                            </div>

                            <!-- Password -->
                            <div class="mb-3">
                                <label class="form-label">🔒 Password</label>
                                <div class="input-group">
                                    <span class="input-group-text">🔒</span>
                                    <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan password" required>
                                    <button type="button" class="btn btn-outline-secondary" onclick="togglePassword()">👁</button>
                                </div>
                            </div>

                            <!-- Tombol Login -->
                            <button type="submit" name="login" class="btn btn-primary w-100 mt-3">➡️ Login Sekarang</button>
                        </form>
                    </div>
                    <div class="card-footer text-center text-muted small">
                        &copy; <?= date("Y") ?> - Sistem Admin Pemain Bola ⚽
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Script Show/Hide Password -->
    <script>
        function togglePassword() {
            const passwordInput = document.getElementById("password");
            passwordInput.type = (passwordInput.type === "password") ? "text" : "password";
        }
    </script>
</body>
</html>
