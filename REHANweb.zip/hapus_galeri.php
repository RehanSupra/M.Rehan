<?php
// hapus_galeri.php
include 'config.php';
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil nama file dari database
    $q = mysqli_query($koneksi, "SELECT foto FROM galeri WHERE id_galeri = '$id'");
    $r = mysqli_fetch_assoc($q);

    if ($r) {
        $foto = $r['foto'];

        // Hapus file dari folder
        $path = __DIR__ . "/uploads/" . $foto;
        if (file_exists($path)) {
            unlink($path);
        }

        // Hapus data dari database
        mysqli_query($koneksi, "DELETE FROM galeri WHERE id_galeri = '$id'");
    }
}

header("Location: galeri.php");
exit;
